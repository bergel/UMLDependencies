package com.fsck.k9.message.extractors;
class PreviewExtractionException extends Exception {
    public PreviewExtractionException(String detailMessage) {
        super(detailMessage);
    }
}