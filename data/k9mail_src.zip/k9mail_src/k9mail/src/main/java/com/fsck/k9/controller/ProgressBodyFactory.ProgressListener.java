package com.fsck.k9.controller;


interface ProgressListener {
        void updateProgress(int progress);
    }