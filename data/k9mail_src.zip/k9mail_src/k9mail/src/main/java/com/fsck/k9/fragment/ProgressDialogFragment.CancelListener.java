package com.fsck.k9.fragment;

public interface CancelListener {
        void onProgressCancel(ProgressDialogFragment fragment);
    }