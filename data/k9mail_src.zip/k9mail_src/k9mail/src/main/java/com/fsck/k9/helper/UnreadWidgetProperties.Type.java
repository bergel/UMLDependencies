package com.fsck.k9.helper;

public enum Type {
        SEARCH_ACCOUNT,
        ACCOUNT,
        FOLDER
    }