package com.fsck.k9.controller;


private enum MemorizingState { STARTED, FINISHED, FAILED }