package com.fsck.k9.activity;


private enum ACCOUNT_LOCATION {
        TOP, MIDDLE, BOTTOM;
    }