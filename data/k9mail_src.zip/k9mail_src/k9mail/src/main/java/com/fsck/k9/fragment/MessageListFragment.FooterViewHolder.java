package com.fsck.k9.fragment;

import android.widget.TextView;
static class FooterViewHolder {
        public TextView main;
    }