package com.fsck.k9.message.extractors;


public enum PreviewType {
        NONE,
        TEXT,
        ENCRYPTED,
        ERROR
    }