package com.fsck.k9;


public enum Theme {
        LIGHT,
        DARK,
        USE_GLOBAL
    }