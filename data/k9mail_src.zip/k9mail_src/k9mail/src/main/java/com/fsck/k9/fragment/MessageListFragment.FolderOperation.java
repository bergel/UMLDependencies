package com.fsck.k9.fragment;

private enum FolderOperation {
        COPY, MOVE
    }