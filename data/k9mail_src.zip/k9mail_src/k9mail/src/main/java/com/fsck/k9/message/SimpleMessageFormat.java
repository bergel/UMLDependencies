package com.fsck.k9.message;
public enum SimpleMessageFormat {
    TEXT,
    HTML
}