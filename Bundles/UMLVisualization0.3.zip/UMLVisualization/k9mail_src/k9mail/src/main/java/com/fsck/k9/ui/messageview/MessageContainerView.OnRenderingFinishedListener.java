package com.fsck.k9.ui.messageview;


interface OnRenderingFinishedListener {
        void onLoadFinished();
    }