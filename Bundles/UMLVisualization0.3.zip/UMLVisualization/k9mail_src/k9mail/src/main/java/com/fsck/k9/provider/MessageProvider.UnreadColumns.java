package com.fsck.k9.provider;


public interface UnreadColumns {
        /**
         * <P>Type: String</P>
         */
        String ACCOUNT_NAME = "accountName";
        /**
         * <P>Type: INTEGER</P>
         */
        String UNREAD = "unread";
    }