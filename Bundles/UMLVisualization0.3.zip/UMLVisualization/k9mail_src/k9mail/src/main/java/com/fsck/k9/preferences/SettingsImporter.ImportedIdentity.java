package com.fsck.k9.preferences;


import android.support.annotation.VisibleForTesting;
@VisibleForTesting
    static class ImportedIdentity {
        public String name;
        public String email;
        public String description;
        public ImportedSettings settings;
    }