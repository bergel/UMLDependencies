package com.fsck.k9.preferences;


import java.util.HashMap;
import java.util.Map;
private static class ImportedSettings {
        public Map<String, String> settings = new HashMap<>();
    }