package com.fsck.k9.activity.compose;


public enum WaitingAction {
        NONE,
        SEND,
        SAVE
    }