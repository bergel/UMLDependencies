package com.fsck.k9.activity.compose;


public interface OnOpenPgpDisableListener {
        void onOpenPgpClickDisable();
    }