package com.fsck.k9.preferences;


private static class ImportedFolder {
        public String name;
        public ImportedSettings settings;
    }