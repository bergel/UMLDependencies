package com.fsck.k9.mail;

public enum Reason {
        Unknown, UseMessage, Expired, MissingCapability, RetrievalFailure
    }