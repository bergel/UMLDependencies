package com.fsck.k9.mail;
public interface DebugStatus {
        boolean enabled();

        boolean debugSensitive();
    }