package com.fsck.k9.mail;

public enum FolderType {
        HOLDS_FOLDERS, HOLDS_MESSAGES,
    }