package com.fsck.k9.mail;

public enum RecipientType {
        TO, CC, BCC, X_ORIGINAL_TO, DELIVERED_TO, X_ENVELOPE_TO
    }