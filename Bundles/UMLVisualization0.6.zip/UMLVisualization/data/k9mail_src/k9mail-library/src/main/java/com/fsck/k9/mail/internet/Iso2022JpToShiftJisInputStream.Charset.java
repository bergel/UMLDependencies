package com.fsck.k9.mail.internet;

private enum Charset {
        ASCII, JISX0201, JISX0208,
    }