package com.fsck.k9.activity;

/**
 * Dialog displaying a color picker.
 */
public interface OnColorChangedListener {
        /**
         * This is called after the user pressed the "OK" button of the dialog.
         *
         * @param color
         *         The ARGB value of the selected color.
         */
        void colorChanged(int color);
    }